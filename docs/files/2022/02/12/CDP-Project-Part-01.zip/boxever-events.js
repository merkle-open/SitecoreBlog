function sendAbandon() {
    // Client data layer as defined by the client e-commerce platform
    var data = {
      _bx_extended_message: "1"
    };

    sendEvent("FORCE_CLOSE", data);
  }

function sendAdd() {
  var data = {
    currency: "EUR",
    language: "EN",
    page: "/products/backed-potato",
    pos: "potato_factory",
    product: {
      type: "POTATO",
      item_id: "BACKEDPOTATO_90",
      name: "Backed Potato of Excellence",
      orderedAt: getTimeStamp(),
      quantity: 1,
      price: 100.0,
      productId: "BACKEDPOTATO0001",
      currencyCode: "EUR",
      originalPrice: 100.0,
      originalCurrencyCode: "EUR",
      referenceId: "BPEX_001-1"
    }
  };
  
  sendEvent("ADD", data);
}

  function sendView() {
    // Client data layer as defined by the client e-commerce platform
    var data = {
      currency: "EUR",
      language: "en",
      page: "/products/backed-potato"
    };

    sendEvent("VIEW", data);
  }

function sendConfirm() {
    var data = {
      currency: "EUR",
      language: "en",
      page: "/confirm",
      pos: "potato_factory",
      product: [
        {
          item_id: "BACKEDPOTATO_90"
        }
      ]
    };
    sendEvent("CONFIRM", data);
  }
    
    
function sendCheckout() {
  var dataCheckout = {
      language: "EN",
      currency: "EUR",
      page: "/checkout",
      pos: "potato_factory",
      reference_id: "BPEX_001-1",
      status: "PURCHASED"
    };
    sendEvent("CHECKOUT", dataCheckout);
}

function sendId() {
    // Client data layer as defined by the client e-commerce platform
    var data = {
      currency: "EUR",
      language: "en",
      firstname: "John",
      lastname: "Doe",
      email: "john.doe@amazingcustomer.com",
      page: "/homepage",
      pos: "potato_factory",
      identifiers: [
        {
          provider: "BXLP",
          id: "123456"
        }
      ]
    };

  sendEvent("IDENTITY", data);
}

  function sendEvent(event, values) {
    // Place an anonymous function in the Boxever queue
    _boxeverq.push(function() {
      var dataEvent = {
        browser_id: Boxever.getID(),
        channel: "WEB",
        type: event
      };

      dataEvent = Object.assign(values, dataEvent);

      // Invoke event create
      // (<event msg>, <callback function>, <format>)
      Boxever.eventCreate(dataEvent, function(data) {}, "json");
    });
  }

function getTimeStamp() {
  var currentdate = new Date(); 
  return currentdate.getFullYear() + '-'
                  + currentdate.getMonth()  + '-' 
                  + currentdate.getDay() + 'T'  
                  + currentdate.getHours() + ':'  
                  + currentdate.getMinutes() + ':' 
                  + currentdate.getSeconds() + '.000Z';  
}